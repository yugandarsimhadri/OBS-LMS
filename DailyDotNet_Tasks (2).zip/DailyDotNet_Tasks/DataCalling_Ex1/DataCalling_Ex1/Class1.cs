﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataCalling_Ex1
{
    public class Class1
    {
        static void Main(string[] args)
        {
            int num = 10;
            float marks = 45.8f;
            double per = 72.5;
            decimal per1 = 3.8m;
            string name = "surya";

            Console.Write("num   ");
            Console.Write("marks  ");
            Console.Write("per  ");
            Console.Write("per1  ");
            Console.WriteLine("name  ");

            Console.Write($"{num}   {marks}   {per}   {per1}   {name}");
            Console.WriteLine();

            //Console.Write("{0}  {1}  {2}  {3}  {4}",num,marks,per,per1,name);
            //Console.WriteLine();
        }
    }
}
