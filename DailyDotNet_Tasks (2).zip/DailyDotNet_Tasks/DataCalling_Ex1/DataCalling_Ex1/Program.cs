﻿using System;

namespace DataCalling_Ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            string Student_Name;
            int Student_Age;
            string Student_Dept;

            Console.WriteLine("Enter Student Name : ");
            Student_Name = Console.ReadLine();
            Console.WriteLine("Enter Student Age : ");
            Student_Age = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter Student Department : ");
            Student_Dept = Console.ReadLine();

            Console.WriteLine("The Student Name is :{0} ", Student_Name);
            Console.WriteLine("The Student Name is :{0}", Student_Age);
            Console.WriteLine("The Student Name is :{0}", Student_Dept);
        }
    }
}
