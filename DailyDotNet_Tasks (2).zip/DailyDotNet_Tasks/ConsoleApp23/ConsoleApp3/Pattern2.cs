﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Pattern2
    {
        static void Main(string[] args)
        {
            int number = 5;

            for (int row = 1; row <= number; row++)
            {
                for (int col = 1; col <= row; col++)
                {
                    Console.Write($"{row}\t");
                }
                Console.WriteLine();
            }
        }
    }
}
