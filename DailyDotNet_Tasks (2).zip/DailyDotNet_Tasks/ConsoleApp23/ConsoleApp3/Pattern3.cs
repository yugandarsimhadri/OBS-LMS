﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Pattern3
    {
        static void Main(string[] args)
        { 
            int number = 5;
            

            for (int row = 1; row <= number; row++)  
            {
                for (int col = 1; col <= row; col++)
                {
                    Console.Write($"{col}\t");
                }
                Console.WriteLine("");
            }

            for (int row = 4; row >= 0; --row)
            {
                for (int col = 1; col <= row; col++)
                {
                    Console.Write($"{col}\t");
                }
                Console.WriteLine("");
            }

        }
    }
}
