﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Pattern4
    {
        static void Main(string[] args)
        {
            int row;
            int col;
            int number =5;
            int add = 1;

            for (row = 1; row <= number; row++)
            {
                for (col = 1; col <= row; col++)
                {
                    Console.Write("{0}\t",add++);
                }
                Console.WriteLine();
            }
        }
    }
}
