﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class ArthamaticOperations
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter first number");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("enter second number");
            int num2 =int.Parse(Console.ReadLine());

            Console.WriteLine("Enter your operations what u want to perform( ADD , SUB , MUL , DIV.)");

            string ch = Console.ReadLine();
            switch (ch)
            {
                case "ADD": Console.WriteLine(num1+num2);
                    break;

                case "SUB": Console.WriteLine(num1-num2);
                    break;

                case "MUL": Console.WriteLine(num1*num2);
                    break;

                case "DIV": Console.WriteLine(num1/num2);
                    break;
                    
                    
            }
        }
    }
}
