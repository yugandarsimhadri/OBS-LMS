﻿using System;
namespace ConsoleApp2
{
    class StrongNumber
    {
        static void Main(string[] args)
        {
            int num = 145;
            int copy = num;
            int sum = 0;
            while (num > 0)
            {
                int digit = num % 10;
                int fact = 1;
                int min = 1;
                while (min <= digit)
                {
                    fact = fact * min;
                    min++;
                }
                sum = sum + fact;
                num = num / 10;
            }
            if (copy == sum)
            {
                Console.WriteLine($"{copy} is strong number");
            }
            else
            {
                Console.WriteLine($"{copy} is not a strong number");
            }
        }
    }
}
