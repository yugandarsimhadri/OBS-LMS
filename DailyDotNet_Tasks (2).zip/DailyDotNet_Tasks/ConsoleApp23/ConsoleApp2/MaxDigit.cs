﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class MaxDigit
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int num = int.Parse(Console.ReadLine());       //54

            int max = num % 10;                           //4
            while (num > 0)                               //true
            {
                int digit = num % 10;                     //4
                if (max < digit)                            
                {
                    max = digit;
                }
                num = num / 10;                          
            }
            Console.WriteLine($"The max digit is {max}");
        }
    }
}
