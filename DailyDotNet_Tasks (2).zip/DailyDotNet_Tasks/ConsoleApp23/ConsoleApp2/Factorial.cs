﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class Factorial
    {
        static void Main(string[] args)                                     
        {
            int num = 12;
            int min = 1;
            int max = num;

            while (min<=max) 
            {
                if (num % min == 0)
                {
                    Console.WriteLine(min);
                }
                min++;
            }
        }
    }
}
