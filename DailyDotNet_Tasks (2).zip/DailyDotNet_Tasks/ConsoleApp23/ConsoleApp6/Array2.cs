﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp6
{
    class Array2
    {
        static void Main(string[] args)
        {
            int[,] array = { { 1,2,3},{4,5,6 },{7,8,9 } };
            for (int row = 0; row <3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    Console.Write($"{array[row,col]} ");
                }
                Console.WriteLine();
            }
        }
    }
}
