﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp6
{
    class Array6
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int rowSum=0;

            int[,] mArray = new int[2, 4] { { 2,2,2,2}, {3,3,3,3 } };

            for (int row = 0; row < 2; row++)
            {
                for (int col = 0; col < 4; col++)
                {
                    Console.WriteLine("{0}\t",mArray[row,col]);
                    rowSum = rowSum + mArray[row,col];

                    sum = sum + rowSum;
                    Console.Write("={0}",rowSum);
                    Console.WriteLine();
                }
                Console.WriteLine($"the sum of array is : {0}",sum);
                Console.ReadLine();
            }
        }
    }
}
