﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp6
{
    class MaxDigit
    {
        static void Main(string[] args)
        {
            int num = 9889;
            if (num>0)
            {
                int getBig = (num + 1) / 1000;
                Console.WriteLine(getBig);
            }
        }
    }
}
