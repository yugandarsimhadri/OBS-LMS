﻿using System;

namespace ConsoleApp6
{
    class Array1
    {
        static void Main(string[] args)
        {
            int[][] jArray = new int[3][];
            jArray[0] = new int[4] { 1, 2, 3, 4 };
            jArray[1] = new int[5] { 2, 3, 4, 5, 6, };
            jArray[2] = new int[2] { 4, 5 };
            //Console.WriteLine(jArray.Length);
            //Console.WriteLine(jArray[0].Length);
            Console.WriteLine("Displaying the array elements");
            for (int row = 0; row < jArray.Length; row++)
            {
                for (int col = 0; col < jArray[row].Length; col++)
                {
                    Console.Write($"{jArray[row][col]}\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine("Displaying the array elements using foreach");
            for (int row = 0; row <jArray.Length; row++)
            {
                foreach (var item in jArray[row])
                {
                    Console.Write($"{item}\t");
                }
                Console.WriteLine();
            }
        }
    }
}
