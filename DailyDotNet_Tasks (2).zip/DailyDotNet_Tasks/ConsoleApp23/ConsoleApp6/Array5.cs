﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp6
{
    class Array5
    {
        static void Main(string[] args)
        {
                    int[] arr = new int[0];
                    int i,j; 
                    int temp = 0;
                    Console.WriteLine("enter five numbers");
            for (i = 0; i <= 4; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("sort the array in decending order");
            for (i=0; i<=4; i++)
            {
                Console.WriteLine(arr[i]);
            }
            for (j = i+1; j <= 4; j++)
            {
                if (arr[i] < arr[j])
                {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
                
        }
       
    }
}
