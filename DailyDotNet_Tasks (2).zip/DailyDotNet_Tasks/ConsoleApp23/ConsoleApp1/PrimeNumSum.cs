﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class PrimeNumSum
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter first number");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("enter second number");
            int num2 = int.Parse(Console.ReadLine());
            Console.WriteLine(PrimeSum(num1, num2));

        }
        private static int PrimeSum(int num1, int num2)
        {
            int sum = 0;
            for (int i = num1; i < num2; i++)
            {
                int count = 0;

                for (int j = 1; j <= 1; j++)
                {
                    if (i % j == 0)
                    {
                        sum = sum + i;

                        Console.WriteLine(sum);
                    }
                    count++;
                }
                if (count == 2)
                {
                    sum = sum + i;
                }
            }
            return sum;

        }
    }
}



