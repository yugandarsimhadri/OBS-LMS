﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class StarPattern
    {
        static void Main(string[] args)
        {
           
                int number = 4;

                for (int row = 1; row <= number; row++)
                {
                    for (int col = 1; col <= row; col++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();
                }
            
        }
    }
}
