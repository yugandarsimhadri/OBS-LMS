﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class SignFinder
    {
        static void Main(string[] args)
        {


            Console.WriteLine("Enter The Number:");
            int num = int.Parse(Console.ReadLine());

            if (num > 0) 
            {
                Console.WriteLine("1 if the given number is positive");
            }
            if (num < 0)
            {
                Console.WriteLine("-1 if the given number is negative");
            }
            if (num == 0)
            {
                Console.WriteLine("0");
            }
        }

    }
}
