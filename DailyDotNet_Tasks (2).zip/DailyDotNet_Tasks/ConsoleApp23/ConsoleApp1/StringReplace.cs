﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class StringReplace
    {
       


        public static void Main()
        {
            String str = "SDIN ";
            Console.WriteLine("NewString: " + str.Replace("IN", "OUT"));



        }
    }
}
