﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class SumOfDigits
    {
        static void Main(string[] args)
        {
            int mod = 0;
            int rem = 0;
            int number;

            Console.WriteLine("Enter a number:");
            number = int.Parse(Console.ReadLine());

            if (number > 10 && number < 99)
            {
                mod = number % 10;
                rem = number / 10;
            }
            Console.WriteLine($"The sum of digits number is: {mod + rem}");
            if (number < 0)
            {
                Console.WriteLine("-3");
            }
            if (number > 99)
            {
                Console.WriteLine("-2");
            }
            if (number > 0 && number < 9)
            {
                Console.WriteLine("-1");
            }
        }
    }
}
