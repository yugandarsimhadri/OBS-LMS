﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class FillMultiples
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number between 1 to 10");
            int num = int.Parse(Console.ReadLine());

            Console.WriteLine(FillMultiple(num));
        }
        private static int FillMultiple(int num)
        {
            int val = 0;

            for (int i = 1; i <= 10; i++)
            {
                val = num * i;
                Console.WriteLine($"{num} * {i} = {val}");
            }
            return val;
        }
    }
}
