﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class StringWeaver
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter first string");
            string str1 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("enter second string");
            string str2 = Convert.ToString(Console.ReadLine());

            string str = "";

            for (int i = 0; i <= str1.Length; i++)
            {
                for (int j = 0; j < str2.Length; j++)
                {
                    if (str1[i] != str2[j])
                    {
                        str = str1[i].ToString() + str2[j].ToString();
                        Console.Write(str);
                    }
                }
            }
        }
    }
}
