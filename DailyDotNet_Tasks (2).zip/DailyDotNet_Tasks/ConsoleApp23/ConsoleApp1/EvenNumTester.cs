﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class EvenNumTester
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the firstnum");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the secondnum");
            int num2 = int.Parse(Console.ReadLine());

            Console.WriteLine(EvenPrint(num1, num2));
        }

        private static int EvenPrint(int num1, int num2)
        {

            for (int i = num1; num1 < num2; num1++)
            {
                if (num1 % 2 == 0)
                {
                    Console.WriteLine($"even : {num1}");
                }
            }
            return num1;
        }
    }
}
