﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class SumOfMul100
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a num1");
            int num1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter a num2");
            int num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter a num3");
            int num3 = int.Parse(Console.ReadLine());

            
            int mul1 = 0;
            int mul2 = 0;
            int mul3 = 0;

            if (num1 <= 0 || num2 <= 0 || num3 <= 0)
            {
                Console.WriteLine("-1");
            }

            else if (num1 % 2 == 0)
            {
                    if(num1 > 0) 
                    { 
                        mul1 = ((num1 / 100) + 1) * 100;

                    }
                    Console.WriteLine($" multiple of {num1} is: {mul1}");
                            
                    if (num2 > 0) 
                    { 
                        mul2 =  ((num2 / 100) + 1) * 100;

                    }
                    Console.WriteLine($" multiple of {num2} is: {mul2}");
                         
                    if (num3 > 0) 
                    { 
                        mul3 = ((num3 / 100) + 1) * 100;

                    }
                    Console.WriteLine($" multiple of {num3} is: {mul3}");
               

                Console.WriteLine();
                Console.WriteLine($"The sum of mul value is: {mul1} + {mul2} + {mul3} = {mul1 + mul2 + mul3}");

            }

            if (num1 % 2 != 0 || num2 % 2 != 0 || num3 % 2 != 0)
            {
                int val1 = num1 * num1 * num1;
                int val2 = num2 * num2 * num2;
                int val3 = num3 * num3 * num3;

                Console.WriteLine($"The {num1} cube value is : {val1}\n The {num2} cube value is : {val2}\n The {num3} cube value is : {val3}");
            }



        }
    }
}
