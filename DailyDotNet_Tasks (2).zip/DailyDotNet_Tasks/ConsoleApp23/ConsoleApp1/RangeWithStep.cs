﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class RangeWithStep
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter first number");
            int startNum = int.Parse(Console.ReadLine());
            Console.WriteLine("enter second number");
            int secondNum = int.Parse(Console.ReadLine());
            Console.WriteLine("enter range num");
            int rangeNum = int.Parse(Console.ReadLine());
            Console.WriteLine();

            if (startNum < 0)
            {
                Console.WriteLine("-1");
            }
            else if (startNum == secondNum)
            {
                Console.WriteLine("-2");
            }
            else if (startNum > secondNum)
            {
                Console.WriteLine("-3");
            }

            for (startNum = startNum; startNum < secondNum; startNum++)
            {
                startNum = startNum + rangeNum;
                
                Console.Write(startNum + " ");
                startNum--;
                Console.WriteLine();
               
            }

        }
    }
}
