﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class SumOfArray
    {
        static void Main(string[] args)
        {
            int[] arr = { 10,20,30,40};
            int i;
            int sum = 0;


            for (i = 0; i < arr.Length; i++)
            {
                sum = sum + arr[i];
            }
            Console.Write("Sum of the array is : {0}\t", sum);
        }
    }
}
