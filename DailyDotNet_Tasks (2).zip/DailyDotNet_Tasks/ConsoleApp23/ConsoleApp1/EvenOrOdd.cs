﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class EvenOrOdd
    {
        static void Main(string[] args)
        {
           
            int num;
            Console.WriteLine("Enter a Number:");
            num = int.Parse(Console.ReadLine());

            if (num % 2 == 0 && num > 0)
            {
                Console.WriteLine(" Even");
            }
            if(num % 2 != 0)
            {
                Console.WriteLine(" ODD");
            }
            if(num <= 0)
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
