﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class FizzBizz
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int num = int.Parse(Console.ReadLine());

            if (num % 3 == 0 && num % 5 == 0)
            {
                Console.WriteLine("FizzBizz");
            }
            else if (num % 3 == 0)
            {
                Console.WriteLine("Fizz");
            }
            else if (num % 5 == 0)
            {
                Console.WriteLine("Bizz");
            }
            else if (num < 0) 
            {
                Console.WriteLine("Error");
            }
            else if (num % 3 != 0 || num % 5 != 0)
            {
                Console.WriteLine(num);
            }


        }

       
    }
}
