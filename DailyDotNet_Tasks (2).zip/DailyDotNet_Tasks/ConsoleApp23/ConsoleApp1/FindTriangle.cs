﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class FindTriangle
    {
        public static void Main()
        {
           
            Console.Write("Check whether a triangle is Equilateral, Isosceles or Scalene:\n");

            Console.Write("Input side 1 of triangle: ");
           int num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input side 2 of triangle: ");
           int num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input side 3 of triangle: ");
            int num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 == num2 && num2 == num3)
            {
                Console.Write("This is an equilateral triangle.\n");
            }
            else if (num1 == num2 || num1 == num3 || num2 == num3)
            {
                Console.Write("This is an isosceles triangle.\n");
            }
            else
            {
                Console.Write("This is a scalene triangle.\n");
            }
            if (num1 < 0)
            {
                Console.WriteLine("-1");
            }
            if (num2 > 99)
            {
                Console.WriteLine("-2");
            }

        }
    }
}