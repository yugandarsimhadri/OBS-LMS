﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class FindMaxArray
    {
        public static void Main()
        {
            int num1, num2 = 0;
            int[] arr = { 4, 5, 45, 21, 54, 2, -76, -54 };

            for (int i = arr.Length - 1; i > -1; i--)
            {
                num1 = arr[i];
                if (num1 > num2)
                {
                    num2 = num1;
                }
            }
            Console.WriteLine(num2);
        }
    }
}
