﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class GeneratePalindrome
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter  number");
            int num1 = int.Parse(Console.ReadLine());
         

            for (int i = num1; i <= 999; i++)
            {
                int number = i;
                int reverse = 0;

                while (number > 0)
                {
                    int digit = number % 10;
                    reverse = reverse * 10 + digit;
                    number = number / 10;

                    if (i == reverse)
                    {
                      Console.WriteLine(reverse);
                    }
                }
            }
        }
    }
}
