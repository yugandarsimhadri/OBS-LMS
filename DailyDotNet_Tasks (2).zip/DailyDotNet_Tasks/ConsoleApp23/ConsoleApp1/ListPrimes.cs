﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class ListPrimes
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter first number");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine(GetPrimeNum(num));
        }

        private static int GetPrimeNum(int num)
        {
            int i;
            for (i = 2; i < num; i++)
            {
                if (num % i == 0)
                {
                    Console.WriteLine($"{num}");
                }
            }
            return num;
        }
    }
}
