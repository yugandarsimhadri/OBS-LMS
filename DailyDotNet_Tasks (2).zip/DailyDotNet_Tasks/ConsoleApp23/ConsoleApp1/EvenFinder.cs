﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class EvenFinder
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a Number:");
            num = int.Parse(Console.ReadLine());

            if (num <= 0)
            {
                Console.WriteLine("-1");
            }

           else if (num % 2 == 0) 
            {
                Console.WriteLine($" The number is an even number:returns 1"); 
            }

            else if(num% 2!=0)
            {
                Console.WriteLine($" The number is an odd number:returns 0"); 
            }
           
        }
    }
}
