﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
   
    class NaturalNumbers
    {
        public static int PrintNext(int firstnum, int Secondnum)
        {
            if (firstnum < 0 || Secondnum < 0)
            {
                Console.WriteLine("-1");
            }
            else if (firstnum == 0 || Secondnum == 0)
            {
                Console.WriteLine("-2");
            }

            if (firstnum <= Secondnum)
            {
                Console.Write(firstnum + " ");
                firstnum++;
                PrintNext(firstnum, Secondnum);
            }
            return firstnum;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a firstnum");
            int firstnum = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Secondnum");
            int Secondnum = int.Parse(Console.ReadLine());
            PrintNext(firstnum, Secondnum);
        }
    }
}
