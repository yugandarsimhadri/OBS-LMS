﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class BoxPattern
    {
        private static void PrintBox(int n, int m)                          
        {
            int row, colum;                                                
            for (row = 1; row <= n; row++)                                   
            {

                for (colum = 1; colum <= m; colum++)
                {
                    if (row == 1 || row == n || colum == 1 || colum == m)
                        Console.Write($"*\t" );
                    else
                        Console.Write("\t");
                }
                Console.WriteLine(" ");
            }
        }
        static void Main(string[] args)
        {
            int row = 4;
            int colum = 5;
            PrintBox(row, colum);
        }                  
    }
}
