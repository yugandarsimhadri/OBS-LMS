﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class LeastNumber
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number 1");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter number 2");
            int num2 = int.Parse(Console.ReadLine());

            if (num1 == 0 || num2 == 0)
            {
                Console.WriteLine("-2");
            }
            else if (num1 < 0 || num2 < 0)
            {
                Console.WriteLine("-1");
            }
            else if (num1 < num2)
            {
                Console.WriteLine($"{num1}");
            }
            else if (num2 < num1)
            {
                Console.WriteLine($"{num2}");
            }
            else 
            {
                Console.WriteLine();
            }
            
        }
    }
}
