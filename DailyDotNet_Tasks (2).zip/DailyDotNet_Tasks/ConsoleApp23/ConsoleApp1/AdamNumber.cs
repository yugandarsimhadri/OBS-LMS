﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class AdamNumber
    {
        public static bool IsAdam(int num) => Square(num) == Reverse(Square(Reverse(num)));

        private static int Square(int num)
        {
            return num * num;
        }

        private static int Reverse(int num)
        {
            int rev = 0;
            while (num > 0)
            {
                rev = rev * 10 + num % 10;
                num /= 10;
            }
            return rev;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(" enter a number");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine(IsAdam(num));
        }
    }
}
