﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class FourPerLine
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number");
            int num = int.Parse(Console.ReadLine());
            if (num > 0 && num < 100)
            {
                for (int val = 1; val <= num; val++)
                {
                    Console.Write(" " + val);

                    if (val % 4 == 0)
                    {
                        Console.WriteLine("");
                    }
                }
            }
            else if (num > 99)
            {
                Console.WriteLine("-3");
            }
        }
    }
}
