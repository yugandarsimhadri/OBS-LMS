﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class IncreDecre
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter number between 1 to 10");
            int num = int.Parse(Console.ReadLine());

            Console.WriteLine(DisplayElement(num));
        }

        private static int DisplayElement(int num)
        {
            int val = 0;
            int[] arr = { 1,4,6,8,5,3,6,7,8,9,5,3,5,7,8,9,7,4,3};

            if (num < 0)
            {
                Console.WriteLine("null");
            }

            else if (num > 0)
            {
                for (int i = 1; i <= num; i++)
                {
                    val = arr[i];
                    Console.WriteLine($"{val}");
                }
            }
            return val;
        }
    }
}
