﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class AlaramClock
    {
        static void Main(string[] args)
        {
            string menu = "code for days";
                   menu += "\n 0=sunday";
                   menu += "\n 1=monday";
                   menu += "\n 2=tuesday";
                   menu += "\n 3=wednesday";
                   menu += "\n 4=thursday";
                   menu += "\n 5=friday";
                   menu += "\n 6=saturday";

            int firstArgument = int.Parse(Console.ReadLine());
            bool secondValue = bool.Parse(Console.ReadLine());

            if (firstArgument <= 0 && firstArgument <= 6)
            {
                Console.WriteLine("invalid input");
            }
            else if ((secondValue = !true) && (secondValue = !false))
            {
                Console.WriteLine("invalid input");
            }
            else if (firstArgument >= 1 && firstArgument <= 5 && (secondValue = true))
            {
                Console.WriteLine("10:00");
            }
            else if (firstArgument >= 1 && firstArgument <= 5 && (secondValue = false))
            {
                Console.WriteLine("7:00");
            }
            else if (firstArgument >= 0 && firstArgument <= 6 && (secondValue = true))
            {
                Console.WriteLine("off");
            }
            else if (firstArgument >= 0 && firstArgument <= 6 && (secondValue = false))
            {
                Console.WriteLine("10:00");
            }
            Console.WriteLine(menu);
        }
    }
}
