﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class OccurenceCounter
    {
 
        public static void Main()
        {
            Console.WriteLine("enter number");
            int num = int.Parse(Console.ReadLine());
           
            int[] arr = {0,1,2,3,4,5,6,7,8,9,2,3,4,5,6,7,8};

            int count = 0;

            for (int i = arr[0]; i < arr.Length; i++)
            {
                if(arr[i] == arr[num])
                {
                    count++;
                }
            }
            Console.WriteLine($"count of {num} is : {count}");
        }
        
    }
}
