﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class SumOfFactors
    {
        static void Main(string[] args)
        {
            int num;
            int i;
            int val = 0;
            Console.WriteLine("Enter the Number:");
            num = int.Parse(Console.ReadLine());
            Console.WriteLine("Factors:");
            for (i = 1; i <= num; i++)
            {
                if (num % i == 0)
                {
                    val = val + i;

                }

            }
            Console.WriteLine(val);



        }
    }
}
