﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class ReverseOrder
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter a firstnum");
            int secondnum = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Secondnum");
            int firstnum = int.Parse(Console.ReadLine());

            Console.WriteLine(PrintReverse(firstnum, secondnum));
        }
        public static string PrintReverse(int firstnum, int secondnum)
        {

            string res = string.Empty;

            for (int i = secondnum - 1; i > firstnum; i--)
            {
                res = res + i + ",";
            }
        
            return res.Substring(0, res.Length - 1) + ".";
           
        }

    }
}
