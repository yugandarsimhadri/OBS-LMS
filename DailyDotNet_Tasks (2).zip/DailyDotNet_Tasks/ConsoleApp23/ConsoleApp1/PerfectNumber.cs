﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class PerfectNumber
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t-----------------------Perfect Number Program-------------------------\n");
            Console.WriteLine("\t\t\t\tEnter a number");
            Console.Write("\t\t\t\t");


            int number = int.Parse(Console.ReadLine());

            int result = IsPerfect(number);
            if (result == 0)

                Console.WriteLine("\t\t\t\tperfect number");
            else
                Console.WriteLine("\t\t\t\tnot perfect");
        }

        private static int IsPerfect(int number)
        {
            int result = 0;

            for (int val = 1; val < number; val++)
            {
                if (number % val == 0)
                {
                    result = result + val;
                }
            }
            return 0;
        }
    }
}
