﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class GreatestNumber
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a num");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a num");
            int num2 = int.Parse(Console.ReadLine());

            while (num1 != num2)
            {
                if (num1 > num2)
                {
                    num1 = num1 - num2;

                }
                else 
                {
                    num2 = num2 - num1;
                }
            }
            Console.WriteLine($"Thegreatest common divisor {num1}");


            if (num1 < 0 || num2 < 0)
            {
                Console.WriteLine("-1");
            }

            else if (num1 == 0 || num2 == 0)
            {
                Console.WriteLine("-2");
            }



        }
    }
    
}
