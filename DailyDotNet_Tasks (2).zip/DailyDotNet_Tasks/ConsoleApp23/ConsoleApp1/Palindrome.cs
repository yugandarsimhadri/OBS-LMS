﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Palindrome
    {
        static void Main()
        {
            int num;
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());
            if (num <= 0 || num == 0)
            {
                Console.WriteLine($" {num} Zero or negative returns -1");
            }
            else if (num < 100 || num > 999)
            {
                Console.WriteLine($" {num} three digit number returns -2");
            }
            else if (num / 100 == num % 10)
            {
                Console.WriteLine($"{num} Palindrome returns 1");
            }
            else if (num<999) { Console.WriteLine("not palindrome"); }
        }
    }
}
