﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class DigitChecker
    {
        static void Main(string[] args)
        {
            int num;
            int sub;
            Console.WriteLine("Enter a Number:");
            num = int.Parse(Console.ReadLine());

            if (num > 10 && num < 99)
            {
                int mod = num % 10;
                int rem = num / 10;
                sub = rem - mod;

                Console.WriteLine($" difference of it's digits: {sub}");
            }

            if (num < 0)
            {
                Console.WriteLine("-3");
            }
            if (num > 99)
            {
                Console.WriteLine("-2");
            }
            if (num > 0 && num < 9)
            {
                Console.WriteLine("-1");
            }
        }
    }
}
