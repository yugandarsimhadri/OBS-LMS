﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Rounder
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number");
            int number = int.Parse(Console.ReadLine());

            if (number <= 0)
            {
                Console.WriteLine("-1");
            }

            else if (number % 2 == 0)
            {
                number = number * number;
                Console.Write($" The given number is EVEN   {number}");
            }
            if (number % 2 != 0)
            {
                number = number * number * number;
                Console.Write($"The given number is ODD  {number}");
            }
        }
    }
}
         