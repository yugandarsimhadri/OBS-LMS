﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class OddRounder
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a num");
            int num1 = int.Parse(Console.ReadLine());
            int mul = 0;
            int value = 10;

            if (num1 % 2 != 0 && num1 > 0)
            {
                for (int i = num1; i <= value; i++)
                {
                    mul = num1 * i;
                   
                }
                Console.WriteLine($" multiple of num1 is: {mul}");
            }

            else if (num1 < 0)
            {
                Console.WriteLine("-1");
            }
            else if (num1 == 0)
            {
                Console.WriteLine("-2");
            }
            else
            {
                Console.WriteLine($"{num1} is even number");
            }
        }
    }
}
