﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class CountBool
    {

        public static void Main(string[] args)
        {
            Console.WriteLine("Enter a num1");
            bool b1 = bool.Parse(Console.ReadLine());
            Console.WriteLine("Enter a num2");
            bool b2 = bool.Parse(Console.ReadLine());
            Console.WriteLine("Enter a num3");
            bool b3 = bool.Parse(Console.ReadLine());

            if (b1 == true && b2 == true && b3 == true ? true : false)
            {
                Console.WriteLine("true");
            }
            else if (b1 == true && b2 == true && b3 == false ? true : false)
            {
                Console.WriteLine("true");
            }
            else if (b1 == true && b2 == false && b3 == false ? false : true)
            {
                Console.WriteLine("false");
            }
            else if (b1 == false && b2 == false && b3 == false ? false : true)
            {
                Console.WriteLine("false");
            }
            else if (b1 == true && b2 == false && b3 == true ? false : true)
            {
                Console.WriteLine("false");
            }
        }
    }
}
