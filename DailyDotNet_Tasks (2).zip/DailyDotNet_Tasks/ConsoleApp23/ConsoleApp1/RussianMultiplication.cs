﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class RussianMultiplication
    {
        static void Main(string[] args)
        {
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            Console.WriteLine(russianPeasant(num1,num2));
        }
        public static int russianPeasant(int num1, int num2)
        {
                int res = 0;
                res = num1 * num2;
                Console.WriteLine(res);
                return res;
        }
    }
}
