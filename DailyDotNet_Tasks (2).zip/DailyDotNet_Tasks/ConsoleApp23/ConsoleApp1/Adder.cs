﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Adder
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter num1");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("enter num2");
            int num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("The value is: "+Sum(num1,num2));
        }

        private static int Sum(int num1, int num2)
        {
            int val = 0;
            if (num1 > 0 && num2 > 0)
            {
                val = num1 + num2;
            }
            else if (num1 <= 0 || num2 > 0)
            {
                Console.WriteLine("Error");
            }
            return val;
        }
    }
}
