﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class MultipleOf100
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a num");
            int num1 = int.Parse(Console.ReadLine());

           
            int mul = 0;

            if (num1 > 0)                                 
            {
                for (int i = num1; i <= 10; i++)        
                {
                    mul = num1 * i;      
                }        
                Console.WriteLine($" multiple of num1 is: {mul}");

            }

            else if (num1 <= 0)
            {
                Console.WriteLine("-1");
            }
           
        }
    }
}
