﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class NumbersInRange
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter a firstnum");
            int firstnum = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Secondnum");
            int secondnum = int.Parse(Console.ReadLine());
           
            Console.WriteLine(PrintNext(firstnum, secondnum));
        }
        public static string PrintNext(int firstnum, int secondnum)
        {
                    
                string res = string.Empty;
           
                for (int i = firstnum + 1; i < secondnum; i++)
                {
                    res = res + i + ",";
                }
                return res.Substring(0, res.Length - 1) + ".";
                  
           
        }
    }
}


      
