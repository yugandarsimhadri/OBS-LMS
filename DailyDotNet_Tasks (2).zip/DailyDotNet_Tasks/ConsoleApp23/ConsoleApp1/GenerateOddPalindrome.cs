﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class GenerateOddPalindrome
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter first number");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("enter second number");
            int num2 = int.Parse(Console.ReadLine());

            for (int i = num1; i <= num2; i++)
            {
                int number = i;
                int reverse = 0;
              
                while (number > 0)
                {
                    int digit = number % 10;
                    reverse = reverse * 10 + digit;
                    number = number / 10;

                    if (i == reverse)
                    {
                        if (reverse % 2 != 0)
                        {
                            Console.WriteLine(reverse);
                        }
                    }
                }
            }
        }
    } 
}
