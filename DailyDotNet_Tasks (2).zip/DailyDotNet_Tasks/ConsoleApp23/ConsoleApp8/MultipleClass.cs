﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class Home 
    {
        static int capital = 10000;
        public void Spent(int amount) 
        {
            Console.WriteLine($"brother you used {amount} Rs");
            capital = capital - amount;

        }
        public void CheckBalence() 
        {
            Console.WriteLine($"Balence left in the Home : {capital} Rs");

        }
    }
    class MultipleClass
    {
        static void Main(string[] args)
        {
            Console.WriteLine("brother1 operations");
            Home br1 = new Home();
            br1.CheckBalence();
            br1.Spent(3000);
            br1.CheckBalence();
            Console.WriteLine("brother2 operations");
            Home br2 = new Home();
            br2.CheckBalence();
        }
    }
}
