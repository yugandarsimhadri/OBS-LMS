﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{

    class InvalidAgeException : Exception 
    {
        string msg;
        public InvalidAgeException() 
        {
            Console.WriteLine("Invalid Age Exception");
        }
        public InvalidAgeException(string msg):base(msg) 
        {
            this.msg = msg;
        }
    }

    class ExceptionEx2
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("enter age");
                int age = int.Parse(Console.ReadLine());

                if (age < 0 || age > 150)
                {
                    throw new InvalidAgeException("Welcome to ojas");

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occured {0}", ex.Message);
            }
            
        }
    }
}
