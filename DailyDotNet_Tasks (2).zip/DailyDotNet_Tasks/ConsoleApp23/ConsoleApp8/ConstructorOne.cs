﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class Sample
    {
        public void show()
        {
            Console.WriteLine("show method from sample class");
        }
    }
    class Employe : Sample
    {
        int Eid;
        string Ename;
        int Esal;

        public void SetEmplyee(int Eid, string Ename, int Esal)
        {
            this.Eid = Eid;
            this.Ename = Ename;
            this.Esal = Esal;

        }
        public void Display()
        {
            Console.WriteLine($"Eid: {Eid}\n Ename: {Ename}\n Esal:{Esal}");
        }
        public override string ToString()
        {
            return $"Eid:{Eid}\tEname:{Ename}\tEsal:{Esal}";
        }
    }
    class ConstructorOne
    {
        static void Main(string[] args)
        {
            Employe emp = new Employe();
            emp.SetEmplyee(113, "surya", 50000);
            emp.show();
            emp.Display();
            Console.WriteLine(emp.ToString());
        }
    }
}
