﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace ConsoleApp8
//{

//    /* we can declare the delegate inside the class or outside of the class also */
//    public delegate void Dell();

//    class GetNumber
//    {
//        //public delegate void Dell();
//        int num1;
//        int num2;

//        public void Sum(int num1, int num2)
//        {
//            Console.WriteLine($"Sum :{num1 + num2}");
//        }
//        public void Sub(int num1, int num2)
//        {
//            Console.WriteLine($"Sub :{num1 - num2}");
//        }
//        public void Mul(int num1, int num2)
//        {
//            Console.WriteLine($"Mul :{num1 * num2}");
//        }
//        public void Div(int num1, int num2)
//        {
//            Console.WriteLine($"Div :{num1 / num2}");
//        }
//    }
//    class DelegateExample
//    {
//        static void Main(string[] args)
//        {
//            Dell d1 = new Dell(new GetNumber().Sum());
//            Dell d2 = new Dell(new GetNumber().Sub());
//            Dell d3 = new Dell(new GetNumber().Mul());
//            Dell d4 = new Dell(new GetNumber().Div());
//            Dell d5 = d1 + d2 + d3 + d4;
//            d5(5, 7);
//        }
//    }
//}
