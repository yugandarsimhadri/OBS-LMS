﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp8
{
    class StringOperations1
    {
        static void Main(string[] args)
        {
            string str = "surya bhaskar grandhi";
            Console.WriteLine(str.IndexOf('r'));
            Console.WriteLine(str.LastIndexOf('a'));
            Console.WriteLine(str.ElementAt(4));
            Console.WriteLine(str.Length);
            Console.WriteLine(str.Substring(3));
            Console.WriteLine(str.Trim());

        }
    }
}
