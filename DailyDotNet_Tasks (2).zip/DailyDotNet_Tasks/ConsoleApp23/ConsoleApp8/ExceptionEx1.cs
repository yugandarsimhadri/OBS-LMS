﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class ExceptionEx1
    {
        static void Main(string[] args)
        {
            try
            {
                int num1 = int.Parse(Console.ReadLine());
                int num2 = int.Parse(Console.ReadLine());

                if (num2 == 0)
                {
                    throw new DivideByZeroException();
                }
                Console.WriteLine($"Quo :{num1 / num2}");
            }
            catch (DivideByZeroException dx)
            {
                Console.WriteLine("num2 not be zero");
            }
            catch (FormatException fx) 
            {
                Console.WriteLine("Enter only integers"+fx.GetType());
            }
        }
        
    }
}
