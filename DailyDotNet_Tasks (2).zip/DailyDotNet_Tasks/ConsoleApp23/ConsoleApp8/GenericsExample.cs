﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class Genre <T,P> 
    {
        public void show(T fVal,P sVal) 
        {
            Console.WriteLine($"First Value :{fVal}\t second value :{sVal}");

        }
    }
    class GenericsExample
    {
        static void Main(string[] args)
        {
            new Genre<int, double>().show(4, 5.6);
            new Genre<double, int>().show(4.5, 7);
            new Genre<string, int>().show("Surya", 45);
        }
    }
}
