﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class ListOfStrongNumbers
    {
        static void Main(string[] args)
        {
            Console.WriteLine(ListOfStrongs(1,500000));
        }

        private static string ListOfStrongs(int v1, int v2)
        {
            string res = string.Empty;
            for (int start = 1; start < v2; start++) 
            {
                if (IsStrong(start)) 
                {
                    res += start + ",";
                }
            }
            return res.Substring(0, res.Length - 1) + ".";
        }

        private static bool IsStrong(int num)
        {
            int copy = num;
            int sum = 0;
            while (num>0) 
            {
                int digit = num % 10;
                sum = sum + Factorial(digit);
                num = num / 10;
            }
            return sum == copy;
        }

        private static int Factorial(int num)
        {
            int fact = 1;
            for (int i=1;i<=num;i++) 
            {
                fact = fact * i;
            }
            return fact;
        }
    }
}
