﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class Student
    {
        public int sId;
        public string sName;
        public int sMarks;

        public void ShowStudent() 
        {
             Console.WriteLine($"ID : {sId}\n Name : {sName} \n Marks : {sMarks}");
        }
        
    }
    class School 
    {
        static void Main(string[] args)
        {
            Student s1 = new Student() { sId = 1, sName = "surya", sMarks = 560 };
            s1.ShowStudent();
        }
    }
}
