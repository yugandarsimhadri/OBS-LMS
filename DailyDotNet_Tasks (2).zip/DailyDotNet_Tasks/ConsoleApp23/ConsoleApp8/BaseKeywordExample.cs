﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class Customer 
    {
       protected int cuId;
       protected string cuName;
       protected string cuContact;

        public Customer(int cuId, string cuName, string cuContact)
        {
            this.cuId = cuId;
            this.cuName = cuName;
            this.cuContact = cuContact;
        }
    }
    class RegiCustomer : Customer 
    {
        double regId;
        double payment;

        public RegiCustomer(int id, string name, string contact, double regId, double payment):base(id,name,contact)
        {
            this.regId = regId;
            this.payment = payment;
        }
        public override string ToString() => $"Cuid : {cuId}\n cuName :{cuName}\n cuContact :{cuContact}\n\n RegId :{regId}\t payment :{payment}\t";
        
    }

    class BaseKeywordExample
    {
        static void Main(string[] args)
        {
            Console.WriteLine(new RegiCustomer(1234,"surya","891932456",43434,34567));
        }
    }
}
