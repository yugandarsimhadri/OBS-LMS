﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    abstract class Empli
    {
        protected int Eid;
        protected string Ename;
        protected int Esal;

        public abstract void SetSal();

        public void ShowEmpDetails()
        {
            Console.WriteLine($"Empid :{Eid}\t Ename :{Ename}\t Esal :{Esal}");
        }
    }

    class FullTimeEmployee : Empli
    {
        public FullTimeEmployee(int eid, string ename)
        {
            Eid = eid;
            Ename = ename;
        }
        public override void SetSal()
        {
            Esal = 500000;
        }
    }

    class PartTimeEmployee : Empli
    {
        public PartTimeEmployee(int eid, string ename)
        {
            Eid = eid;
            Ename = ename;
        }
        public override void SetSal()
        {
            Esal = 25000;
        }
    }

    class AbstractExample
    {
        static void Main(string[] args)
        {
            FullTimeEmployee femp = new FullTimeEmployee(111, "Surya");
            femp.SetSal();
            femp.ShowEmpDetails();
            PartTimeEmployee pemp = new PartTimeEmployee(114, "Vijender");
            pemp.SetSal();
            pemp.ShowEmpDetails();
        }
    }
}
