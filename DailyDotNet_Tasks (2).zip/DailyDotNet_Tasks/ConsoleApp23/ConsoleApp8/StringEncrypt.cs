﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp8
{
    class StringEncrypt
    {
        public static string Encrypt(string str) 
        {

            str = str.ToLower();
            string alphas = "abcdefghijklmnopqrstuvwxyz";
            string revalphas = "zyxwvutsrqponmlkjihgfedcba";
            string res = string.Empty;
            for (int i = 0; i < str.Length; i++)
            {
                res = res + revalphas.ElementAt(alphas.IndexOf(str[i]));
            }

            return res;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Encrypt("SuryaBhaskarGrandhi"));
        }
    }
}
