﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class SortArrayDesc
    {
        static void Main(string[] args)
        {
            int[] array = { 123,546,202,305,409,143};
            Console.WriteLine(GetMaxNumber(array));
        }

        private static int GetMaxNumber(int[] array)
        {
            return ArrayToNum(SortArrayDesending(GetMaxDigitArray(array)));
        }

        private static int[] GetMaxDigitArray(int[] array)
        {
            int[] MxDigitArray = new int[array.Length];

            for (int i = 0; i < array.Length; i++)
            {
                MxDigitArray[i] = GetMaxDigit(array[i]);
            }
            return MxDigitArray;
        }

        private static int GetMaxDigit(int num)
        {
            int max = num % 10;
            while (num > 0)
            {
                int digit = num % 10;
                if (max < digit)
                {
                    max = digit;
                }
                num = num / 10;
            }
            return max;
        }

        private static int[] SortArrayDesending(int[] array)
        {
            Array.Sort(array);
            Array.Reverse(array);
            return array;
        }

        private static int ArrayToNum(int[] array)
        {
            int res = 0;
            foreach (int i in array)
            {
                res = res * 10 + i;
            }
            return res;
        }
    }
}
