﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class MaxDigit
    {
        public static int GetMaxDigit(int num)        //253
        {
            int max = num % 10;                       //3
            while (num > 0)                           //253>0 true 25>0 true  
            {
                int digit = num % 10;                 //3,5
                if (max < digit)                      //3<3, 3<5
                {
                    max = digit;                      //5
                }
                num = num / 10;                          //25
            }
            return max;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(GetMaxDigit(76956));

        }
    }
}
