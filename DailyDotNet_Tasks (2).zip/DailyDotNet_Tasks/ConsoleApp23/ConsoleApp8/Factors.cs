﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class Factors
    {
        static void Main(string[] args)
        {
            int num;
            int i;
            
            Console.WriteLine("Enter the Number:");
            num = int.Parse(Console.ReadLine());
            Console.WriteLine("Factors:");
            for (i = 1; i <= num; i++)
            {
                if (num % i == 0)
                {
                   
                    Console.WriteLine(i);
                }
            }
           
        }
    }
}
