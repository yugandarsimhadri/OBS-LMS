﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class LuckyNumber
    {
        public static int GetLuckyNumber(string dob)
        {
            string[] res = dob.Split("-");
            int date = int.Parse(res[0]);
            int month = ConvertMonthToNumber(res[1]);
            int year = int.Parse(res[2]);
            int sum = date + month + year;
            while (sum>9) 
            {
                sum = SumOfDigits(sum);
            }
            return sum;
        }

        private static int ConvertMonthToNumber(string month)
        {
            month = month.ToLower();
            string[] months = { "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec" };
            for (int i = 0; i < months.Length; i++)
            {
                if (month.Contains(months[i]))
                {
                    return i + 1;
                }
                
            }
            return 0;
        }

        private static int SumOfDigits(int num)
        {
            int sum = 0;
            while (num>0)
            {
                sum += num % 10;
                num /= 10;
            }
            return sum;
        }

        static void Main(string[] args)
        {
            Console.WriteLine($"Your LuckyNumber is: {GetLuckyNumber("26-Jan-1993")}");
        }
    }
}
