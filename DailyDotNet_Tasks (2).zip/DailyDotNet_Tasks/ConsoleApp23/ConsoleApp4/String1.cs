﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace ConsoleApp4
//{
//    class String1
//    {
//        static void Main(string[] args)
//        {
//            string firstString = "surya";
//            string secondString = "surya";
//            Console.WriteLine(firstString.CompareTo(secondString));
//        }
//    }
//}
