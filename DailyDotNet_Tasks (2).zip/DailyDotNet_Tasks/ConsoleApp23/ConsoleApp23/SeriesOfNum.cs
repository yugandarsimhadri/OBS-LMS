﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp23
{
    class SeriesOfNum
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int number = Convert.ToInt32(Console.ReadLine()); // 5 
      
            int digit = 1;                
            while (digit <= number)       // 1<=5 true,2<=5 true,3<=5 true,4<=5 true,5<=5
            {
                Console.WriteLine(digit);//  1,2,3,4,5
                digit++;                 //  2,3,4,5
            }
        }
    }
}
