﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp23
{
    class Palindrome
    {
        static void Main(string[] args)
        {
            int num = 121;
            int copy = num;
            int rev = 0;

            while ( num>0) 
            {
                int digit = num % 10;
                rev = rev * 10 + digit;
                num = num / 10;
            }
            Console.WriteLine($"The reverse of a given digit is  {rev}");
            if (copy == rev)
            {
                Console.WriteLine("The number is palindrome");
            }
            else 
            {
                Console.WriteLine("the number is not a palindrome");
            }
        }
    }
}
