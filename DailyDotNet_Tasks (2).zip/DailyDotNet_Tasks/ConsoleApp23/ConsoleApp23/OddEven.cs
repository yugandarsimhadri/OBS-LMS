﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp23
{
    class OddEven
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number:");
            int num = int.Parse(Console.ReadLine());

            if (num % 2 == 0)
            {
                Console.WriteLine("1");
            }
            else
            {
                Console.WriteLine("0");
            };
        }
    }
}
