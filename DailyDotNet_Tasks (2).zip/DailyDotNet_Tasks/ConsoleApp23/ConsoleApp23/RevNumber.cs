﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp23
{
    class RevNumber
    {
        static void Main(string[] args)
        {
            int number = 987;
            int revNum = 0;
            while (number > 0)                
            {
                int digit = number % 10;    
                revNum = revNum * 10 + digit;         
                number = number / 10;       

            }
            Console.WriteLine($"The Reverse of digits value is  {revNum}");
        }
    }
}
