﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp23
{
    class SumOfDigits
    {
        static void Main(string[] args)
        {
            int number = 342;
            int sum = 0;
            while (number>0)                //342>0 true, 34>0 true 3>0 true
            {
                int digit = number % 10;    //2,4,3
                sum = sum + digit;          //2,6,9
                number = number / 10;       //34,3,0

            }
            Console.WriteLine($"The sum of digits value is  {sum}");
        }
    }
}
