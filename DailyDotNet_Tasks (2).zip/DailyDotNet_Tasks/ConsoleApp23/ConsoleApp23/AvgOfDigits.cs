﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp23
{
    class AvgOfDigits
    {
        static void Main(string[] args)
        {
            int number = 222;
            int sum = 0;
            int count = 0;
            int avg = 0;
            while (number > 0)              
            {
                int digit = number % 10;    
                sum = sum + digit;          
                count++;
                avg = sum / count;
                number = number / 10;       
            }
            Console.WriteLine($"The avg of digits value is  {avg}");
        }
    }
}
