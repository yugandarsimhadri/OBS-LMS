﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp23
{
    class CountNumbers
    {
        static void Main(string[] args)
        {
            int number = 345;
            int count = 0;

            while (number > 0)           // 345>0 true, 34>0 true, 3>0 true, 0>0
            {
                int digit = number % 10; // 5,4,3
                count++;                 // 1,2,3  
                number = number / 10;    // 34,3,0 
            }
            Console.WriteLine($"The total count of digits is  {count}");

        }
    }
}
