﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp23
{
    class SeparateNumbers
    {
        static void Main(string[] args)
        {
            int number = 786;
            while (number>0)              // 786>0 true, 78>0 true, 7>0 true
            {
                int digit = number % 10;  // digit=6, digit=8, digit=7
                Console.WriteLine(digit); // 6,8,7
                number = number / 10;     //78,7,0
            }
          


        }
    }
}
