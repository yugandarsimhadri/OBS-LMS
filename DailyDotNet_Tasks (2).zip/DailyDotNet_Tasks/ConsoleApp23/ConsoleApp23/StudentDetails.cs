﻿using System;

namespace ConsoleApp23
{

    class StudentDetails
    {
        static void Main(string[] args)
        {
            string StudentName;
            int StudentAge;
            string StudentDept;

            Console.WriteLine("Enter Student Name : ");
            StudentName = Console.ReadLine();
            Console.WriteLine("Enter Student Age : ");
            StudentAge = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter Student Department : ");
            StudentDept = Console.ReadLine();

            Console.WriteLine("The Student Name is :{0} ", StudentName);
            Console.WriteLine("The Student Name is :{0}", StudentAge);
            Console.WriteLine("The Student Name is :{0}", StudentDept);
        }
    }
}
