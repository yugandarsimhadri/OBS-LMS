﻿using System;

namespace ClassLibrary1
{
    public class SumOfDigits
    {
        static void Main(string[] args) 
        {
            int mod = 0;
            int remainer = 0;
            int num;
            Console.WriteLine("Enter a Number:");
            num = int.Parse(Console.ReadLine());

            if (num > 10 && num < 99)
            {
                mod = num % 10;
                remainer = num / 10;
            }
            Console.WriteLine($"The sum of digits of the given number is: {mod + remainer}");
            if (num < 0)
            {
                Console.WriteLine("-3");
            }
            if (num > 99)
            {
                Console.WriteLine("-2");
            }
            if (num > 0 && num < 9)
            {
                Console.WriteLine("it returns -1");
            }
        }
    }
}
